namespace atividade_ii.Models
{
    public class ItemPedido
    {
        public string descricao { get; set; }
        public double precoUni { get; set; }
        public int qtd { get; set; }
        /*  public ItemPedido(string d, double p, int q){
              descricao = d;
              precoUni = p;  
              qtd = q;
          }*/
    }
}